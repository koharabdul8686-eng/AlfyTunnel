package com.alfy.tunnel

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private val GREEN = Color(0xFF3DDC84)

@Composable
fun LogLine(l: String) {
    val i = l.indexOf("] ")
    val ts = if (i > 0) l.substring(0, i + 1) else ""
    val msg = if (i > 0) l.substring(i + 2) else l
    val green = msg == "Connected"
    val bold = green || msg.startsWith("Response:")
    Text(
        buildAnnotatedString {
            if (ts.isNotEmpty()) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(ts) }
                append(" ")
            }
            withStyle(SpanStyle(color = if (green) GREEN else Color.Unspecified, fontWeight = if (bold) FontWeight.Bold else null)) {
                append(msg)
            }
        },
        fontFamily = FontFamily.Monospace, fontSize = 12.sp
    )
}

@Composable
private fun SpeedRow() {
    val dl by Mon.dl.collectAsState()
    val ul by Mon.ul.collectAsState()
    val dbm by Mon.dbm.collectAsState()
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("↓ " + Mon.fmt(dl), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("↑ " + Mon.fmt(ul), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(Mon.dbmText(dbm), fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun SpeedCard(host: String, onGraph: () -> Unit, onFloat: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        Mon.dbmUse(ctx, true)
        onDispose { Mon.dbmUse(ctx, false) }
    }
    val fl by Prefs.floatOn.collectAsState()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                host, Modifier.rainbow(Prefs.P_HOST), color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1
            )
            SpeedRow()
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = onGraph) { Text("Grafik layar penuh") }
                Text("  Mengambang", Modifier.weight(1f), fontSize = 13.sp)
                Switch(checked = fl, onCheckedChange = onFloat)
            }
        }
    }
}

@Composable
fun GraphScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        val w = (ctx as? Activity)?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Mon.dbmUse(ctx, true)
        onDispose {
            w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            Mon.dbmUse(ctx, false)
        }
    }
    val tick = Mon.hTick.collectAsState()
    val sp by Prefs.rb[Prefs.P_GRAPH].collectAsState()
    val clk = if (sp > 0f) Rb.t.collectAsState() else null
    val d = remember { FloatArray(Mon.N) }
    val u = remember { FloatArray(Mon.N) }
    Box(Modifier.fillMaxSize().background(Color(0xFF0A0C10))) {
        Canvas(Modifier.fillMaxSize().padding(start = 8.dp, end = 8.dp, top = 84.dp, bottom = 16.dp)) {
            tick.value
            val n = Mon.history(d, u)
            for (k in 1..3) {
                val y = size.height * k / 4f
                drawLine(Color(0x22FFFFFF), Offset(0f, y), Offset(size.width, y), 1f)
            }
            if (n < 2) return@Canvas
            var mx = 1024f
            for (i in 0 until n) mx = max(mx, max(d[i], u[i]))
            mx *= 1.1f
            val pd = Path()
            val pu = Path()
            for (i in 0 until n) {
                val x = size.width * i / (Mon.N - 1).toFloat() + size.width * (Mon.N - n) / (Mon.N - 1).toFloat()
                val yd = size.height * (1f - d[i] / mx)
                val yu = size.height * (1f - u[i] / mx)
                if (i == 0) {
                    pd.moveTo(x, yd)
                    pu.moveTo(x, yu)
                } else {
                    pd.lineTo(x, yd)
                    pu.lineTo(x, yu)
                }
            }
            val off = Rb.offset(clk?.value ?: 0f, sp)
            val br = Brush.horizontalGradient(Rb.colors(off, 7, 50f).let { it + it.first() }, 0f, size.width)
            drawPath(pu, Color(0xAAFFFFFF), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(pd, br, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Kembali") }
            val dl by Mon.dl.collectAsState()
            val ul by Mon.ul.collectAsState()
            Column(Modifier.padding(start = 8.dp)) {
                Text(
                    "↓ " + Mon.fmt(dl), Modifier.rainbow(Prefs.P_GRAPH), color = Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 22.sp, fontFamily = FontFamily.Monospace
                )
                Text("↑ " + Mon.fmt(ul), color = Color(0xCCFFFFFF), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
            }
        }
    }
}

private fun permOn(c: Context, k: Int): Boolean = when (k) {
    0 -> (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()
    1 -> c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    2 -> Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)
    else -> Build.VERSION.SDK_INT < 23 ||
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
}

@Composable
private fun Perm(title: String, on: Boolean, steps: List<String>, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(if (on) "AKTIF" else "MATI", color = if (on) GREEN else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
            for (s in steps) Text(s.uppercase(), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            if (!on) Button(onClick = onClick, Modifier.fillMaxWidth()) { Text("AKTIFKAN") }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, toast: (String) -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rs by Prefs.resume.collectAsState()
    val dbg by Prefs.dbg.collectAsState()
    val pkg = ctx.packageName
    fun bump() {
        Prefs.resume.value = Prefs.resume.value + 1
    }

    val notifReq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump() }
    val locReq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bump() }
    val bgPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { Img.saveBg(ctx, uri) }.getOrDefault(false) }
            toast(if (ok) "Latar diganti" else "Gambar tidak bisa dibaca")
        }
    }
    val iconPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) { runCatching { Img.square(ctx, uri, 192) }.getOrNull() }
            if (bmp == null) {
                toast("Gambar tidak bisa dibaca")
            } else if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
                toast("Launcher tidak mendukung shortcut")
            } else {
                val info = ShortcutInfoCompat.Builder(ctx, "alfy_custom")
                    .setShortLabel("AlfyTunnel")
                    .setIcon(IconCompat.createWithBitmap(bmp))
                    .setIntent(Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                    .build()
                ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
                toast("Konfirmasi penambahan shortcut di layar utama")
            }
        }
    }

    fun go(i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) { toast("Tidak bisa membuka pengaturan") }
    }

    val appDetail = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
    val names = listOf("Notifikasi", "Speedometer mengambang", "Grafik layar penuh", "Hostname")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Kembali") }
            Text("Pengaturan & izin", style = MaterialTheme.typography.titleLarge)
        }
        Text("Izin (tanpa root)", style = MaterialTheme.typography.titleMedium)
        Perm(
            "Notifikasi", remember(rs) { permOn(ctx, 0) },
            listOf("1. tekan aktifkan.", "2. pilih izinkan.", "3. jika tidak muncul: pengaturan > notifikasi > aktifkan alfytunnel.")
        ) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifReq.launch(Manifest.permission.POST_NOTIFICATIONS)
            else go(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg))
        }
        Perm(
            "Lokasi (untuk dBm)", remember(rs) { permOn(ctx, 1) },
            listOf("1. tekan aktifkan.", "2. pilih saat aplikasi digunakan, lalu presisi.", "3. hanya dipakai membaca sinyal seluler (dBm).")
        ) { locReq.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
        Perm(
            "Overlay (speedometer mengambang)", remember(rs) { permOn(ctx, 2) },
            listOf("1. tekan aktifkan.", "2. cari alfytunnel.", "3. nyalakan izinkan tampil di atas aplikasi lain.", "4. tekan kembali.")
        ) { go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg"))) }
        Perm(
            "Baterai (tanpa dibatasi)", remember(rs) { permOn(ctx, 3) },
            listOf("1. tekan aktifkan.", "2. cari alfytunnel.", "3. pilih tidak dibatasi / jangan dioptimalkan.")
        ) { go(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        FilledTonalButton(onClick = { go(appDetail) }, Modifier.fillMaxWidth()) { Text("Buka pengaturan aplikasi") }
        HorizontalDivider()

        Text("Kecepatan gerak pelangi (0 = diam)", style = MaterialTheme.typography.titleMedium)
        for (i in 0..3) {
            val v by Prefs.rb[i].collectAsState()
            Text(names[i] + ": " + if (v <= 0f) "DIAM" else v.roundToInt().toString())
            Slider(
                value = v, onValueChange = { Prefs.setRb(i, it.roundToInt().toFloat()) },
                valueRange = 0f..10f, steps = 9
            )
        }
        HorizontalDivider()

        Text("Personalisasi", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { bgPick.launch("image/*") }) { Text("Latar dari galeri") }
            TextButton(onClick = { Img.clearBg(ctx) }) { Text("Hapus latar") }
        }
        FilledTonalButton(onClick = { iconPick.launch("image/*") }, Modifier.fillMaxWidth()) { Text("Ikon dari galeri (shortcut)") }
        Text(
            "Batasan: Android tidak mengizinkan aplikasi mengganti ikon aslinya dengan gambar bebas. " +
                "Yang dibuat adalah shortcut baru di layar utama dengan gambar pilihan; ikon lama dihapus manual bila perlu.",
            fontSize = 12.sp
        )
        HorizontalDivider()

        Text("Log", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Hentikan log setelah Connected", Modifier.weight(1f))
            val lo by Prefs.logOff.collectAsState()
            Switch(checked = lo, onCheckedChange = { Prefs.setLogOff(it) })
        }
        HorizontalDivider()

        Text("Speedometer", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Log debug speedometer", Modifier.weight(1f))
            Switch(checked = dbg, onCheckedChange = { Prefs.setDbg(it) })
        }
        Text(
            "Kecepatan dihitung dari byte yang lewat antarmuka TUN tiap 250 ms + EMA. TrafficStats tidak dipakai karena " +
                "menghitung ganda saat VPN aktif. Header IP ikut terhitung, overhead SSH tidak, jadi bisa sedikit " +
                "berbeda dari 1DM+. dBm: nilai di luar -140..-30 ditampilkan \"-\"; Wi-Fi tidak dibaca.",
            fontSize = 12.sp
        )
    }
}
