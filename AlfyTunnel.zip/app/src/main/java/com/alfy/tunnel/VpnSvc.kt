package com.alfy.tunnel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import org.json.JSONObject
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class VpnSvc : VpnService() {
    companion object {
        const val ACT_START = "com.alfy.tunnel.START"
        const val ACT_STOP = "com.alfy.tunnel.STOP"
        const val EXTRA = "cfg"
        private const val CH = "alfy_status"
        private const val NID = 1
    }

    @Volatile private var gen = 0
    private var worker: Thread? = null
    private var tun: ParcelFileDescriptor? = null
    private var link: SshLink? = null
    private var stack: TunStack? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACT_START) {
            fg("Menghubungkan…")
            val cfg = try {
                Config.fromJson(JSONObject(i?.getStringExtra(EXTRA) ?: ""))
            } catch (e: Exception) {
                null
            }
            if (cfg == null) {
                Bus.log("Config tidak valid")
                shutdown()
            } else if (worker?.isAlive != true) {
                val g = ++gen
                worker = Thread { run(cfg, g) }.also { it.start() }
            }
        } else {
            shutdown()
        }
        return START_NOT_STICKY
    }

    private fun run(cfg: Config, g: Int) {
        Bus.status.value = St.CONNECTING
        val l = SshLink(this, cfg)
        link = l
        var attempt = 0
        try {
            while (gen == g) {
                try {
                    Bus.log("Menghubungkan (${if (cfg.mode == 0) "SSH WebSocket" else "SSH SSL/TLS"})…")
                    l.connect()
                    if (gen != g) break
                    val existing = stack
                    if (tun == null || existing == null) {
                        val t = build(cfg) ?: throw IOException("Gagal membuat antarmuka VPN (izin dicabut?)")
                        tun = t
                        val s = TunStack(FileInputStream(t.fileDescriptor), FileOutputStream(t.fileDescriptor), l)
                        stack = s
                        Thread { s.loop() }.also { it.isDaemon = true }.start()
                    }
                    Bus.status.value = St.CONNECTED
                    attempt = 0
                    note("Terhubung: ${cfg.name}")
                    Bus.log("Tunnel aktif")
                    while (gen == g && l.alive) Thread.sleep(1500)
                    if (gen == g) Bus.log("Koneksi SSH terputus")
                } catch (e: InterruptedException) {
                    break
                } catch (e: Throwable) {
                    Bus.log("Gagal: ${e.message ?: e.javaClass.simpleName}")
                }
                l.close()
                if (gen != g) break
                stack?.reset()
                attempt++
                Bus.status.value = St.RECONNECTING
                note("Menyambung ulang…")
                val w = minOf(30, attempt * 3)
                Bus.log("Coba lagi dalam $w detik (percobaan $attempt)")
                for (k in 0 until w * 2) {
                    if (gen != g) break
                    Thread.sleep(500)
                }
            }
        } catch (e: InterruptedException) {
        }
        if (gen == g) shutdown()
    }

    private fun build(cfg: Config): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("AlfyTunnel")
            .setMtu(1500)
            .setBlocking(true)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
        if (cfg.dnsOn) {
            b.addDnsServer(cfg.dns1.trim())
            if (cfg.dns2.isNotBlank()) b.addDnsServer(cfg.dns2.trim())
        }
        try {
            b.addDisallowedApplication(packageName)
        } catch (e: Exception) {
        }
        return b.establish()
    }

    @Synchronized
    private fun shutdown() {
        gen++
        worker?.interrupt()
        try { link?.close() } catch (e: Exception) { }
        link = null
        stack?.stop()
        stack = null
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        if (Bus.status.value != St.IDLE) Bus.log("Terputus")
        Bus.status.value = St.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        shutdown()
    }

    override fun onDestroy() {
        if (Bus.status.value != St.IDLE) shutdown()
        super.onDestroy()
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Status VPN", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, CH)
        } else {
            b = Notification.Builder(this)
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, VpnSvc::class.java).setAction(ACT_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return b.setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("AlfyTunnel")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "PUTUS", stop).build())
            .build()
    }

    private fun fg(t: String) {
        val n = notif(t)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NID, n)
        }
    }

    private fun note(t: String) {
        getSystemService(NotificationManager::class.java).notify(NID, notif(t))
    }
}
