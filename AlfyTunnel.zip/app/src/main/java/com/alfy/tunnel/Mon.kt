package com.alfy.tunnel

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/** Pengaturan UI sederhana (SharedPreferences), dipakai Activity dan Service. */
object Prefs {
    const val P_NOTIF = 0
    const val P_FLOAT = 1
    const val P_GRAPH = 2
    const val P_HOST = 3

    private var sp: SharedPreferences? = null
    val rb = List(4) { MutableStateFlow(3f) }
    val floatOn = MutableStateFlow(false)
    val dbg = MutableStateFlow(true)
    val bgVer = MutableStateFlow(0)
    val resume = MutableStateFlow(0)

    fun init(c: Context) {
        if (sp != null) return
        val s = c.applicationContext.getSharedPreferences("alfy_ui", Context.MODE_PRIVATE)
        sp = s
        for (i in 0..3) rb[i].value = s.getFloat("rb$i", 3f)
        floatOn.value = s.getBoolean("float", false)
        dbg.value = s.getBoolean("dbg", true)
    }

    fun setRb(i: Int, v: Float) {
        rb[i].value = v
        sp?.edit()?.putFloat("rb$i", v)?.apply()
    }

    fun setFloat(v: Boolean) {
        floatOn.value = v
        sp?.edit()?.putBoolean("float", v)?.apply()
    }

    fun setDbg(v: Boolean) {
        dbg.value = v
        sp?.edit()?.putBoolean("dbg", v)?.apply()
    }

    fun getInt(k: String, d: Int) = sp?.getInt(k, d) ?: d
    fun putInt(k: String, v: Int) {
        sp?.edit()?.putInt(k, v)?.apply()
    }
}

/** Satu jam bersama untuk semua animasi pelangi di UI. Hanya berdetak selama ada yang mengamati. */
object Rb {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val t: StateFlow<Float> = flow {
        while (true) {
            emit(SystemClock.uptimeMillis() / 1000f)
            delay(60)
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(1000), 0f)

    const val DEG_PER_SEC = 20f

    fun offset(sec: Float, speed: Float): Float = if (speed <= 0f) 0f else (sec * speed * DEG_PER_SEC) % 360f

    fun colors(off: Float, n: Int = 7, step: Float = 50f): List<Color> =
        List(n) { Color.hsv(((off + it * step) % 360f + 360f) % 360f, 0.8f, 1f) }
}

/** Isi teks/gambar dengan gradasi pelangi. Animasi dibaca di fase gambar (tanpa recompose). Speed 0 = statis. */
@Composable
fun Modifier.rainbow(part: Int): Modifier {
    val sp by Prefs.rb[part].collectAsState()
    val clk: State<Float>? = if (sp > 0f) Rb.t.collectAsState() else null
    return this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val off = Rb.offset(clk?.value ?: 0f, sp)
            drawRect(
                Brush.horizontalGradient(Rb.colors(off, 7, 50f).let { it + it.first() }, 0f, size.width.coerceAtLeast(1f)),
                blendMode = BlendMode.SrcIn
            )
        }
}

object Mon {
    val rx = AtomicLong() // byte menuju perangkat (download), dihitung di TUN
    val tx = AtomicLong() // byte dari perangkat (upload), dihitung di TUN
    val dl = MutableStateFlow(0f)
    val ul = MutableStateFlow(0f)
    val dbm = MutableStateFlow<Int?>(null)
    val hTick = MutableStateFlow(0)

    const val N = 240
    private val hd = FloatArray(N)
    private val hu = FloatArray(N)
    private var pos = 0
    private var cnt = 0

    @Synchronized
    fun push(d: Float, u: Float) {
        hd[pos] = d
        hu[pos] = u
        pos = (pos + 1) % N
        if (cnt < N) cnt++
        hTick.value = hTick.value + 1
    }

    @Synchronized
    fun history(outD: FloatArray, outU: FloatArray): Int {
        val start = (pos - cnt + N) % N
        for (i in 0 until cnt) {
            outD[i] = hd[(start + i) % N]
            outU[i] = hu[(start + i) % N]
        }
        return cnt
    }

    @Synchronized
    fun resetSpeed() {
        rx.set(0)
        tx.set(0)
        dl.value = 0f
        ul.value = 0f
        pos = 0
        cnt = 0
        hTick.value = hTick.value + 1
    }

    fun fmt(bps: Float): String = when {
        bps < 1024f -> String.format(Locale.US, "%.0f B/s", bps)
        bps < 1048576f -> String.format(Locale.US, "%.1f KB/s", bps / 1024f)
        else -> String.format(Locale.US, "%.2f MB/s", bps / 1048576f)
    }

    // ---- dBm: scan otomatis tiap 3 detik, nilai tidak valid -> null ("-") ----
    private var users = 0
    private var appCtx: Context? = null
    private var ht: HandlerThread? = null
    private var bg: Handler? = null
    private val scanRun = object : Runnable {
        override fun run() {
            val c = appCtx
            dbm.value = if (c == null) null else try { readDbm(c) } catch (e: Throwable) { null }
            if (users > 0) bg?.postDelayed(this, 3000)
        }
    }

    @Synchronized
    fun dbmUse(ctx: Context, on: Boolean) {
        appCtx = ctx.applicationContext
        if (on) {
            users++
            if (users == 1) {
                val t = HandlerThread("alfy-dbm").also { it.start() }
                ht = t
                bg = Handler(t.looper).also { it.post(scanRun) }
            }
        } else {
            users = maxOf(0, users - 1)
            if (users == 0) {
                bg?.removeCallbacksAndMessages(null)
                ht?.quitSafely()
                ht = null
                bg = null
                dbm.value = null
            }
        }
    }

    private fun ok(v: Int) = v in -140..-30

    private fun cellDbm(ci: CellInfo): Int? = when {
        ci is CellInfoLte -> ci.cellSignalStrength.dbm
        ci is CellInfoWcdma -> ci.cellSignalStrength.dbm
        ci is CellInfoGsm -> ci.cellSignalStrength.dbm
        ci is CellInfoCdma -> ci.cellSignalStrength.dbm
        Build.VERSION.SDK_INT >= 29 && ci is CellInfoNr -> ci.cellSignalStrength.dbm
        else -> null
    }

    private fun readDbm(c: Context): Int? {
        val tm = c.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return null
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val v = tm.signalStrength?.cellSignalStrengths?.map { it.dbm }?.firstOrNull { ok(it) }
                if (v != null) return v
            } catch (e: Throwable) {
            }
        }
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                @Suppress("MissingPermission")
                val l = tm.allCellInfo
                val v = l?.filter { it.isRegistered }?.mapNotNull { cellDbm(it) }?.firstOrNull { ok(it) }
                if (v != null) return v
            } catch (e: Throwable) {
            }
        }
        return null
    }

    fun dbmText(v: Int?): String = if (v == null) "-" else "$v dBm"
}
