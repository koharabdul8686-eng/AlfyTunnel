package com.alfy.tunnel

import android.net.VpnService
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.SocketFactory
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"

class SshLink(private val svc: VpnService, private val cfg: Config) {
    @Volatile private var ses: Session? = null
    @Volatile private var pending: Socket? = null
    private val dnsCache = HashMap<String, InetAddress>()

    val alive: Boolean get() = ses?.isConnected == true

    fun connect() {
        close()
        val sv = Srv.parse(cfg.server) ?: throw IOException("Format server salah")
        val sock = prepare(sv)
        val s = JSch().getSession(sv.user, sv.host, sv.port)
        s.setPassword(sv.pass)
        s.setConfig("StrictHostKeyChecking", "no")
        s.setConfig("PreferredAuthentications", "password,keyboard-interactive")
        s.setConfig(
            "kex",
            JSch.getConfig("kex") + ",diffie-hellman-group14-sha1,diffie-hellman-group-exchange-sha1,diffie-hellman-group1-sha1"
        )
        s.setConfig("server_host_key", JSch.getConfig("server_host_key") + ",ssh-rsa,ssh-dss")
        s.setSocketFactory(object : SocketFactory {
            override fun createSocket(host: String, port: Int): Socket = sock
            override fun getInputStream(socket: Socket): InputStream = object : FilterInputStream(socket.getInputStream()) {
                private val sb = StringBuilder()
                private var done = false
                private fun feed(b: Int) {
                    if (done) return
                    sb.append(b.toChar())
                    if (b == 10 || sb.length > 255) {
                        done = true
                        Bus.log("H: " + esc(sb.toString()))
                        Bus.log(sb.toString().trim())
                    }
                }
                override fun read(): Int {
                    val c = super.read()
                    if (c >= 0) feed(c)
                    return c
                }
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    val n = super.read(b, off, len)
                    if (!done) for (i in 0 until n) feed(b[off + i].toInt() and 255)
                    return n
                }
            }
            override fun getOutputStream(socket: Socket): OutputStream = socket.getOutputStream()
        })
        s.setServerAliveInterval(20000)
        s.setServerAliveCountMax(3)
        s.setDaemonThread(true)
        try {
            s.connect(20000)
        } catch (e: Exception) {
            try { sock.close() } catch (x: Exception) { }
            throw IOException("SSH gagal: ${e.message}")
        }
        ses = s
        pending = null
        Bus.log("Auth complete")
    }

    fun open(host: String, port: Int): ChannelDirectTCPIP {
        val s = ses?.takeIf { it.isConnected } ?: throw IOException("SSH tidak terhubung")
        val ch = s.openChannel("direct-tcpip") as ChannelDirectTCPIP
        ch.setHost(host)
        ch.setPort(port)
        return ch
    }

    fun close() {
        try { pending?.close() } catch (e: Exception) { }
        pending = null
        try { ses?.disconnect() } catch (e: Exception) { }
        ses = null
    }

    private fun resolve(h: String): InetAddress = synchronized(dnsCache) {
        dnsCache.getOrPut(h) {
            try { InetAddress.getByName(h) } catch (e: Exception) { throw IOException("Host tidak ditemukan: $h") }
        }
    }

    private fun payloadRaw(sv: Srv): String {
        val raw = cfg.payload.ifBlank { Config.DEFAULT_PAYLOAD }
        return raw.replace("\r", "").replace("\n", "")
            .replace("[host]", sv.host).replace("[port]", sv.port.toString())
            .replace("[protocol]", "HTTP/1.1")
    }

    private fun payload(sv: Srv): String =
        payloadRaw(sv).replace("[ua]", UA)
            .replace("[crlf]", "\r\n").replace("[cr]", "\r").replace("[lf]", "\n")

    private fun esc(t: String) = t.replace("\r", "\\r").replace("\n", "\\n")

    private fun prepare(sv: Srv): Socket {
        val px = if (cfg.proxy.isBlank()) null else parseHp(cfg.proxy)
        val tls = cfg.mode == 1
        val tHost = px?.first ?: sv.host
        val tPort = px?.second ?: sv.port
        Bus.log("Connecting to proxy $tHost port $tPort")
        val addr = resolve(tHost)
        Bus.log("Ip resolved, ${addr.hostAddress}")
        var s = Socket()
        pending = s
        svc.protect(s)
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(addr, tPort), 15000)
        s.soTimeout = 15000
        if (!tls) {
            Bus.log("Sending Payload: " + payloadRaw(sv))
            send(s, payload(sv))
            readHttp(s)
        } else {
            if (px != null) {
                send(s, "CONNECT ${sv.host}:${sv.port} HTTP/1.1\r\nHost: ${sv.host}:${sv.port}\r\n\r\n")
                readHttp(s)
            }
            val sni = cfg.sni.trim().ifEmpty { sv.host }
            val tm = object : X509TrustManager {
                override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf(tm), null)
            val ssl = ctx.socketFactory.createSocket(s, sni, tPort, true) as SSLSocket
            pending = ssl
            try {
                val p = ssl.sslParameters
                p.serverNames = listOf(SNIHostName(sni))
                ssl.sslParameters = p
            } catch (e: Exception) {
                Bus.log("SNI tidak valid, dipakai default")
            }
            ssl.startHandshake()
            Bus.log("TLS OK (SNI: $sni)")
            s = ssl
            if (cfg.payload.isNotBlank()) {
                Bus.log("Sending Payload: " + payloadRaw(sv))
                send(s, payload(sv))
                readHttp(s)
            }
        }
        s.soTimeout = 0
        return s
    }

    private fun send(s: Socket, t: String) {
        val o = s.getOutputStream()
        o.write(t.toByteArray(Charsets.ISO_8859_1))
        o.flush()
    }

    private fun readHttp(s: Socket): String {
        val i = s.getInputStream()
        val sb = StringBuilder()
        while (!sb.endsWith("\r\n\r\n")) {
            val c = i.read()
            if (c < 0) throw IOException("Koneksi ditutup saat menunggu respons")
            sb.append(c.toChar())
            if (sb.length > 8192) throw IOException("Respons terlalu panjang")
        }
        Bus.log("H: " + esc(sb.toString()))
        val line = sb.lineSequence().first().trim()
        Bus.log("Response: $line")
        val code = line.split(" ").getOrNull(1)?.toIntOrNull()
        if (code != 101 && code != 200) throw IOException("Respons ditolak: $line")
        return line
    }
}
