package com.alfy.tunnel

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlfyTheme { App() } }
    }
}

@Composable
fun AlfyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF4DD0C4),
            onPrimary = Color(0xFF00201D),
            secondaryContainer = Color(0xFF1F3B38),
            background = Color(0xFF0F1115),
            surface = Color(0xFF0F1115),
            surfaceVariant = Color(0xFF1B1F27),
            error = Color(0xFFE57373),
            onError = Color(0xFF1A0000)
        ),
        content = content
    )
}

fun startVpn(ctx: Context, c: Config) {
    Bus.status.value = St.CONNECTING
    ContextCompat.startForegroundService(
        ctx,
        Intent(ctx, VpnSvc::class.java).setAction(VpnSvc.ACT_START).putExtra(VpnSvc.EXTRA, c.toJson().toString())
    )
}

@Composable
fun Field(
    v: String, label: String, enabled: Boolean = true, lines: Int = 1, mono: Boolean = false,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = v,
        onValueChange = onChange,
        label = { Text(label) },
        enabled = enabled,
        singleLine = lines == 1,
        minLines = lines,
        textStyle = if (mono) LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace) else LocalTextStyle.current,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun ModeRow(text: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick, enabled = enabled)
        Text(text, Modifier.clickable(enabled = enabled, onClick = onClick))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val cfgs by vm.configs.collectAsState()
    val cur by vm.cur.collectAsState()
    val st by Bus.status.collectAsState()
    val logs by Bus.logs.collectAsState()
    val snack = remember { SnackbarHostState() }
    var menu by remember { mutableStateOf(false) }
    var renameId by remember { mutableStateOf<String?>(null) }
    var delId by remember { mutableStateOf<String?>(null) }
    var showPaste by remember { mutableStateOf(false) }
    var pasteText by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<List<Config>?>(null) }
    val locked = st != St.IDLE

    fun toast(m: String) {
        scope.launch { snack.showSnackbar(m) }
    }

    fun doImport(t: String) {
        vm.parseBackup(t).onSuccess { l ->
            if (vm.conflicts(l) > 0) {
                pending = l
            } else {
                vm.importConfigs(l, false)
                toast("${l.size} config dipulihkan")
            }
        }.onFailure { toast("Format tidak valid: ${it.message}") }
    }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val vpnPerm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn(ctx, vm.cur.value) else toast("Izin VPN ditolak")
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val text = vm.backupText()
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }
            }.onSuccess { toast("Backup tersimpan") }.onFailure { toast("Gagal menyimpan: ${it.message}") }
        }
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    String(ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }, Charsets.UTF_8)
                }
            }.onSuccess { doImport(it) }.onFailure { toast("Gagal membaca berkas: ${it.message}") }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Config", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    FilledTonalButton(onClick = { vm.add() }, enabled = !locked) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Tambah")
                    }
                }
                HorizontalDivider()
                LazyColumn {
                    items(cfgs, key = { it.id }) { c ->
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (c.id == cur.id) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                                .clickable(enabled = !locked) {
                                    vm.select(c.id)
                                    scope.launch { drawer.close() }
                                }
                                .padding(start = 16.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(c.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            IconButton(onClick = { renameId = c.id }) { Icon(Icons.Default.Edit, "Ganti nama") }
                            IconButton(onClick = { delId = c.id }, enabled = !locked) { Icon(Icons.Default.Delete, "Hapus") }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            topBar = {
                TopAppBar(
                    title = { Text("AlfyTunnel") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Config") }
                    },
                    actions = {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Backup ke file") }, onClick = {
                                menu = false
                                saver.launch("alfytunnel.atcfg")
                            })
                            DropdownMenuItem(text = { Text("Salin backup sebagai teks") }, onClick = {
                                menu = false
                                clip.setText(AnnotatedString(vm.backupText()))
                                toast("Backup disalin")
                            })
                            DropdownMenuItem(text = { Text("Restore dari file") }, onClick = {
                                menu = false
                                opener.launch(arrayOf("*/*"))
                            })
                            DropdownMenuItem(text = { Text("Restore dari teks") }, onClick = {
                                menu = false
                                pasteText = ""
                                showPaste = true
                            })
                        }
                    }
                )
            }
        ) { pad ->
            Column(
                Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Mode", style = MaterialTheme.typography.labelLarge)
                ModeRow("SSH WebSocket (80)", cur.mode == 0, !locked) { vm.edit { it.copy(mode = 0) } }
                ModeRow("SSH SSL/TLS (443)", cur.mode == 1, !locked) { vm.edit { it.copy(mode = 1) } }
                Field(cur.server, "Server (host:port@user:password)", !locked) { v -> vm.edit { it.copy(server = v) } }
                Field(cur.proxy, "Proxy (host:port, boleh kosong)", !locked) { v -> vm.edit { it.copy(proxy = v) } }
                Field(cur.sni, "SNI / TLS (mode SSL/TLS)", !locked && cur.mode == 1) { v -> vm.edit { it.copy(sni = v) } }
                Field(cur.payload, "Payload ([host] [port] [crlf] [cr] [lf] [protocol])", !locked, 4, true) { v ->
                    vm.edit { it.copy(payload = v) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Custom DNS", Modifier.weight(1f))
                    Switch(checked = cur.dnsOn, onCheckedChange = { v -> vm.edit { it.copy(dnsOn = v) } }, enabled = !locked)
                }
                if (cur.dnsOn) {
                    Field(cur.dns1, "DNS Primary", !locked) { v -> vm.edit { it.copy(dns1 = v) } }
                    Field(cur.dns2, "DNS Secondary", !locked) { v -> vm.edit { it.copy(dns2 = v) } }
                }
                Text(
                    when (st) {
                        St.IDLE -> "Status: terputus"
                        St.CONNECTING -> "Status: menghubungkan…"
                        St.CONNECTED -> "Status: terhubung"
                        St.RECONNECTING -> "Status: menyambung ulang…"
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(
                    onClick = {
                        if (st == St.IDLE) {
                            val e = vm.validate(cur)
                            if (e != null) {
                                toast(e)
                            } else {
                                val i = VpnService.prepare(ctx)
                                if (i != null) vpnPerm.launch(i) else startVpn(ctx, cur)
                            }
                        } else {
                            ctx.startService(Intent(ctx, VpnSvc::class.java).setAction(VpnSvc.ACT_STOP))
                        }
                    },
                    colors = if (st == St.IDLE) ButtonDefaults.buttonColors()
                    else ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(if (st == St.IDLE) "KONEK" else "PUTUS") }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Log", Modifier.weight(1f).padding(start = 4.dp), style = MaterialTheme.typography.labelLarge)
                            TextButton(onClick = { Bus.clear() }) { Text("Bersihkan") }
                        }
                        val ls = rememberLazyListState()
                        LaunchedEffect(logs.size) {
                            if (logs.isNotEmpty()) ls.scrollToItem(logs.size - 1)
                        }
                        LazyColumn(state = ls, modifier = Modifier.fillMaxWidth().height(220.dp)) {
                            items(logs) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                        }
                    }
                }
            }
        }
    }

    renameId?.let { id ->
        var t by remember(id) { mutableStateOf(cfgs.firstOrNull { it.id == id }?.name ?: "") }
        AlertDialog(
            onDismissRequest = { renameId = null },
            title = { Text("Ganti nama") },
            text = { OutlinedTextField(value = t, onValueChange = { t = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    if (t.isNotBlank()) vm.rename(id, t.trim())
                    renameId = null
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { renameId = null }) { Text("Batal") } }
        )
    }

    delId?.let { id ->
        AlertDialog(
            onDismissRequest = { delId = null },
            title = { Text("Hapus config?") },
            text = { Text("Config \"${cfgs.firstOrNull { it.id == id }?.name ?: ""}\" akan dihapus permanen.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(id)
                    delId = null
                }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { delId = null }) { Text("Batal") } }
        )
    }

    if (showPaste) {
        AlertDialog(
            onDismissRequest = { showPaste = false },
            title = { Text("Restore dari teks") },
            text = {
                OutlinedTextField(
                    value = pasteText, onValueChange = { pasteText = it },
                    label = { Text("Tempel isi backup (JSON)") }, minLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showPaste = false
                    doImport(pasteText)
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { showPaste = false }) { Text("Batal") } }
        )
    }

    pending?.let { l ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Config sudah ada") },
            text = {
                Text("${vm.conflicts(l)} dari ${l.size} config punya ID yang sama dengan config yang ada. Timpa atau simpan sebagai salinan baru?")
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        vm.importConfigs(l, false)
                        pending = null
                        toast("Dipulihkan sebagai salinan")
                    }) { Text("Salinan") }
                    TextButton(onClick = {
                        vm.importConfigs(l, true)
                        pending = null
                        toast("Config ditimpa")
                    }) { Text("Timpa") }
                }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Batal") } }
        )
    }
}
